import { defineConfig } from "@lovable.dev/vite-tanstack-config";
import { VitePWA, type VitePWAOptions } from "vite-plugin-pwa";
import type { Plugin } from "vite";

const pwaOptions: Partial<VitePWAOptions> = {
  strategies: "generateSW",
  filename: "sw.js",
  registerType: "autoUpdate",
  injectRegister: null,
  manifest: false, // static public/manifest.webmanifest
  devOptions: { enabled: false },
  workbox: {
    globPatterns: ["**/*.{js,css,woff2,png,svg,webmanifest}"],
    globIgnores: ["**/*.wasm"],
    navigateFallback: null,
    cleanupOutdatedCaches: true,
    clientsClaim: true,
    skipWaiting: true,
    runtimeCaching: [
      {
        urlPattern: ({ request, url, sameOrigin }) => sameOrigin && request.mode === "navigate" && !url.pathname.startsWith("/~oauth"),
        handler: "NetworkFirst",
        options: { cacheName: "pages", networkTimeoutSeconds: 4, expiration: { maxEntries: 30, maxAgeSeconds: 7 * 24 * 3600 } },
      },
      {
        urlPattern: ({ url, sameOrigin }) => sameOrigin && url.pathname.startsWith("/assets/"),
        handler: "CacheFirst",
        options: { cacheName: "assets", expiration: { maxEntries: 200, maxAgeSeconds: 30 * 24 * 3600 } },
      },
      {
        urlPattern: ({ url }) => url.origin === "https://fonts.googleapis.com" || url.origin === "https://fonts.gstatic.com",
        handler: "StaleWhileRevalidate",
        options: { cacheName: "fonts", expiration: { maxEntries: 20 } },
      },
    ],
  },
};

function clientPwa(): Plugin[] {
  const outDirSync: Plugin = {
    name: "net-studio:pwa-client-outdir",
    enforce: "pre",
    configResolved(config) {
      const dir = config.environments?.["client"]?.build?.outDir;
      if (dir) pwaOptions.outDir = dir;
    },
  };
  const pwa = VitePWA(pwaOptions).flat() as Plugin[];
  for (const plugin of pwa) plugin.applyToEnvironment = (env) => env.name === "client";
  return [outDirSync, ...pwa];
}

export default defineConfig({
  tanstackStart: {
    server: { entry: "server" },
  },
  plugins: [clientPwa()],
});
