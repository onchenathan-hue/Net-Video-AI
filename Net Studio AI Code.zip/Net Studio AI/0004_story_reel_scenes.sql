ALTER TABLE public.video_clips ADD COLUMN IF NOT EXISTS reel_id uuid;
ALTER TABLE public.video_clips ADD COLUMN IF NOT EXISTS scene_index integer;
ALTER TABLE public.video_clips ADD COLUMN IF NOT EXISTS caption text;