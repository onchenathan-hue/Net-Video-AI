import { Link, useNavigate } from "@tanstack/react-router";
import { useQueryClient } from "@tanstack/react-query";
import { useEffect, useState } from "react";
import { Menu } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from "@/components/ui/sheet";
import { InstallAppButton } from "@/components/InstallAppButton";

const LINKS = [
  { to: "/dashboard", label: "Dashboard" },
  { to: "/projects", label: "Projects" },
  { to: "/library", label: "Library" },
  { to: "/settings", label: "Settings" },
] as const;

export function SiteHeader() {
  const [email, setEmail] = useState<string | null>(null);
  const [menuOpen, setMenuOpen] = useState(false);
  const navigate = useNavigate();
  const qc = useQueryClient();

  useEffect(() => {
    supabase.auth.getUser().then(({ data }) => setEmail(data.user?.email ?? null));
    const { data } = supabase.auth.onAuthStateChange((_e, s) => setEmail(s?.user?.email ?? null));
    return () => data.subscription.unsubscribe();
  }, []);

  async function signOut() {
    setMenuOpen(false);
    await qc.cancelQueries();
    qc.clear();
    await supabase.auth.signOut();
    navigate({ to: "/auth", replace: true });
  }

  return (
    <header className="sticky top-0 z-40 border-b border-border bg-background/80 pt-[env(safe-area-inset-top)] backdrop-blur">
      <div className="mx-auto grid min-h-14 max-w-6xl grid-cols-[minmax(0,1fr)_auto] items-center gap-2 px-4 py-2 sm:min-h-16 sm:px-5 md:flex md:justify-between">
        <Link to="/" className="flex min-w-0 items-center gap-2 font-display text-base font-bold sm:text-lg">
          <img src="/icon-192.png" alt="" width={32} height={32} className="h-8 w-8 shrink-0 rounded-lg" />
          <span className="truncate">Net Studio <span className="text-primary">AI</span></span>
        </Link>
        <nav className="flex shrink-0 items-center gap-1">
          <InstallAppButton className="hidden sm:inline-flex" />
          {email ? (
            <>
              <div className="hidden items-center gap-1 md:flex">
                {LINKS.slice(0, 3).map((l) => (
                  <Button key={l.to} asChild variant="ghost" size="sm"><Link to={l.to}>{l.label}</Link></Button>
                ))}
                <Button asChild size="sm"><Link to="/studio" search={{}}>Studio</Link></Button>
                <Button asChild variant="ghost" size="sm"><Link to="/settings">Settings</Link></Button>
                <Button variant="ghost" size="sm" onClick={signOut}>Sign out</Button>
              </div>
              <Button asChild size="sm" className="h-10 md:hidden"><Link to="/studio" search={{}}>Studio</Link></Button>
              <Sheet open={menuOpen} onOpenChange={setMenuOpen}>
                <SheetTrigger asChild>
                  <Button variant="ghost" size="icon" className="h-10 w-10 md:hidden" aria-label="Open menu"><Menu /></Button>
                </SheetTrigger>
                <SheetContent side="right" className="w-72 pt-[calc(env(safe-area-inset-top)+1.5rem)]">
                  <SheetHeader><SheetTitle>Menu</SheetTitle></SheetHeader>
                  <div className="mt-6 flex flex-col gap-1">
                    <Button asChild size="lg" className="justify-start" onClick={() => setMenuOpen(false)}><Link to="/studio" search={{}}>Studio</Link></Button>
                    {LINKS.map((l) => (
                      <Button key={l.to} asChild variant="ghost" size="lg" className="justify-start" onClick={() => setMenuOpen(false)}>
                        <Link to={l.to}>{l.label}</Link>
                      </Button>
                    ))}
                    <InstallAppButton size="lg" className="mt-2 justify-start" />
                    <Button variant="ghost" size="lg" className="mt-4 justify-start text-muted-foreground" onClick={signOut}>Sign out</Button>
                  </div>
                </SheetContent>
              </Sheet>
            </>
          ) : (
            <>
              <InstallAppButton className="h-10 sm:hidden" />
              <Button asChild size="sm" className="h-10 sm:h-8"><Link to="/auth">Start free</Link></Button>
            </>
          )}
        </nav>
      </div>
    </header>
  );
}
