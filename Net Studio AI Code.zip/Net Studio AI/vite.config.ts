// @lovable.dev/vite-tanstack-config already includes the following — do NOT add them manually
// or the app will break with duplicate plugins:
//   - TanStack devtools (dev-only, first), tanstackStart, viteReact, tailwindcss, tsConfigPaths,
//     nitro (build-only using cloudflare as a default target), VITE_* env injection, @ path alias,
//     React/TanStack dedupe, error logger plugins, and sandbox detection (port/host/strictPort).
// You can pass additional config via defineConfig({ vite: { ... }, etc... }) if needed.
import { defineConfig } from "@lovable.dev/vite-tanstack-config";
import { VitePWA, type VitePWAOptions } from "vite-plugin-pwa";
import type { Plugin } from "vite";

// Offline worker for the published app. Registration lives only in src/lib/pwa.ts (guarded against dev/preview).
const pwaOptions: Partial<VitePWAOptions> = {
  strategies: "generateSW",
  filename: "sw.js",
  registerType: "autoUpdate",
  injectRegister: null,
  manifest: false, // static public/manifest.webmanifest
  devOptions: { enabled: false },
  workbox: {
    globPatterns: ["**/*.{js,css,woff2,png,svg,webmanifest}"],
    globIgnores: ["**/*.wasm"],
    navigateFallback: null,
    cleanupOutdatedCaches: true,
    clientsClaim: true,
    skipWaiting: true,
    runtimeCaching: [
      {
        // Pages: network first; fall back to the last copy on weak mobile data.
        urlPattern: ({ request, url, sameOrigin }) => sameOrigin && request.mode === "navigate" && !url.pathname.startsWith("/~oauth"),
        handler: "NetworkFirst",
        options: { cacheName: "pages", networkTimeoutSeconds: 4, expiration: { maxEntries: 30, maxAgeSeconds: 7 * 24 * 3600 } },
      },
      {
        // Hashed build files never change, so cache-first is safe (includes the lazily loaded video processor).
        urlPattern: ({ url, sameOrigin }) => sameOrigin && url.pathname.startsWith("/assets/"),
        handler: "CacheFirst",
        options: { cacheName: "assets", expiration: { maxEntries: 200, maxAgeSeconds: 30 * 24 * 3600 } },
      },
      {
        urlPattern: ({ url }) => url.origin === "https://fonts.googleapis.com" || url.origin === "https://fonts.gstatic.com",
        handler: "StaleWhileRevalidate",
        options: { cacheName: "fonts", expiration: { maxEntries: 20 } },
      },
    ],
  },
};

// TanStack Start builds client, SSR and server environments; the worker belongs only in the client (public) output.
function clientPwa(): Plugin[] {
  const outDirSync: Plugin = {
    name: "net-studio:pwa-client-outdir",
    enforce: "pre",
    configResolved(config) {
      const dir = config.environments?.["client"]?.build?.outDir;
      if (dir) pwaOptions.outDir = dir;
    },
  };
  const pwa = VitePWA(pwaOptions).flat() as Plugin[];
  for (const plugin of pwa) plugin.applyToEnvironment = (env) => env.name === "client";
  return [outDirSync, ...pwa];
}

export default defineConfig({
  tanstackStart: {
    // Redirect TanStack Start's bundled server entry to src/server.ts (our SSR error wrapper).
    // nitro/vite builds from this
    server: { entry: "server" },
  },
  plugins: [clientPwa()],
});
