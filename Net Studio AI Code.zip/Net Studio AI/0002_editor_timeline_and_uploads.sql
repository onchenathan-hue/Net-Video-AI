ALTER TABLE public.video_projects ADD COLUMN timeline jsonb NOT NULL DEFAULT '[]'::jsonb;
GRANT UPDATE ON public.video_projects TO authenticated;
CREATE POLICY "own update" ON public.video_projects FOR UPDATE TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

CREATE TABLE public.media_uploads (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid(),
  name text NOT NULL,
  storage_path text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, DELETE ON public.media_uploads TO authenticated;
GRANT ALL ON public.media_uploads TO service_role;
ALTER TABLE public.media_uploads ENABLE ROW LEVEL SECURITY;
CREATE POLICY "own media select" ON public.media_uploads FOR SELECT TO authenticated USING (auth.uid() = user_id);
CREATE POLICY "own media insert" ON public.media_uploads FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
CREATE POLICY "own media delete" ON public.media_uploads FOR DELETE TO authenticated USING (auth.uid() = user_id);

CREATE POLICY "own clip files delete" ON storage.objects FOR DELETE TO authenticated
  USING (bucket_id = 'clips' AND (storage.foldername(name))[1] = auth.uid()::text);