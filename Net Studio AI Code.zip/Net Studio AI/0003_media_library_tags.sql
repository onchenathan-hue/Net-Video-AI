ALTER TABLE public.media_uploads ADD COLUMN IF NOT EXISTS tags text[] NOT NULL DEFAULT '{}';
GRANT UPDATE ON public.media_uploads TO authenticated;
CREATE POLICY "own media update" ON public.media_uploads FOR UPDATE TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
CREATE INDEX IF NOT EXISTS media_uploads_tags_idx ON public.media_uploads USING gin (tags);