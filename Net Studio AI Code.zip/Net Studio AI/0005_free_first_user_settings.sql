CREATE TABLE public.studio_settings (user_id uuid PRIMARY KEY, paid_ai_enabled boolean NOT NULL DEFAULT false, output_format text NOT NULL DEFAULT '9:16' CHECK (output_format IN ('9:16','16:9','1:1')), updated_at timestamptz NOT NULL DEFAULT now());
GRANT SELECT, INSERT, UPDATE, DELETE ON public.studio_settings TO authenticated;
GRANT ALL ON public.studio_settings TO service_role;
ALTER TABLE public.studio_settings ENABLE ROW LEVEL SECURITY;
CREATE POLICY own_settings_select ON public.studio_settings FOR SELECT TO authenticated USING (auth.uid() = user_id);
CREATE POLICY own_settings_insert ON public.studio_settings FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
CREATE POLICY own_settings_update ON public.studio_settings FOR UPDATE TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
CREATE POLICY own_settings_delete ON public.studio_settings FOR DELETE TO authenticated USING (auth.uid() = user_id);