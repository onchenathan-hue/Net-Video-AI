<!-- Lovable wrote this file; it is not part of your task. Keep it, and ask the user before deleting or reverting it. -->

# North star

Creators publish videos that audiences watch and share.

## Metric

Finished videos downloaded or exported each week
