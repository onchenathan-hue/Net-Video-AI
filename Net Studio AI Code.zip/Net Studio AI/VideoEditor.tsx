import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useEffect, useMemo, useRef, useState } from "react";
import { toast } from "sonner";
import { ArrowDown, ArrowUp, Download, Loader2, Pause, Play, Plus, Save, Scissors, Trash2, Upload, X } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { uploadFootage } from '@/lib/media-upload';
import { FORMATS, type OutputFormat } from '@/lib/free-first';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { getSettings } from '@/lib/settings.functions';
import { downloadVideo } from '@/lib/local-export';

type Item = { id: string; path: string; name: string; in: number; out: number; duration: number };
type Media = { path: string; name: string; kind: "ai" | "upload"; tags?: string[] };

const tapBtn = "grid h-11 w-11 place-items-center rounded-md hover:bg-background/60 active:bg-background/60 disabled:opacity-30 sm:h-8 sm:w-8";
const fmt = (s: number) => `${Math.floor(s / 60)}:${String(Math.floor(s % 60)).padStart(2, "0")}.${Math.floor((s % 1) * 10)}`;

function probeDuration(url: string) {
  return new Promise<number>((resolve, reject) => {
    const v = document.createElement("video");
    v.preload = "metadata";
    v.onloadedmetadata = () => resolve(v.duration);
    v.onerror = () => reject(new Error("Could not read this video"));
    v.src = url;
  });
}

export function VideoEditor({ projectId, initial, vertical }: { projectId: string; initial: unknown; vertical: boolean }) {
  const qc = useQueryClient();
  const [items, setItems] = useState<Item[]>(Array.isArray(initial) ? (initial as Item[]) : []);
  const [selected, setSelected] = useState<string | null>(null);
  const [playing, setPlaying] = useState(false);
  const [cursor, setCursor] = useState(0); // index in timeline during playback
  const [uploading, setUploading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [q, setQ] = useState("");
  const [format, setFormat] = useState<OutputFormat>(vertical ? '9:16' : '16:9');
  const [exporting, setExporting] = useState(false);
  const [exportStatus, setExportStatus] = useState('');
  const [result, setResult] = useState<Blob | null>(null);
  const controller = useRef<AbortController | null>(null);
  const settings = useQuery({ queryKey: ['settings'], queryFn: () => getSettings() });
  useEffect(() => { const value = settings.data?.output_format; if (value && FORMATS.some((f) => f === value)) setFormat(value as OutputFormat); }, [settings.data?.output_format]);
  useEffect(() => { setResult(null); }, [items, format]);
  useEffect(() => () => controller.current?.abort(), []);
  const videoRef = useRef<HTMLVideoElement>(null);

  const media = useQuery({
    queryKey: ["media", projectId],
    queryFn: async (): Promise<Media[]> => {
      const [clips, uploads] = await Promise.all([
        supabase.from("video_clips").select("id, storage_path, created_at").eq("project_id", projectId).eq("status", "completed"),
        supabase.from("media_uploads").select("name, storage_path, tags").order("created_at", { ascending: false }),
      ]);
      const ai = (clips.data ?? [])
        .flatMap((c, i) => c.storage_path ? [{ path: c.storage_path, name: `AI clip ${i + 1}`, kind: "ai" as const }] : []);
      const up = (uploads.data ?? []).map((u) => ({ path: u.storage_path, name: u.name, kind: "upload" as const, tags: u.tags }));
      return [...ai, ...up];
    },
  });

  const allPaths = useMemo(
    () => Array.from(new Set([...(media.data ?? []).map((m) => m.path), ...items.map((i) => i.path)])),
    [media.data, items],
  );
  const urls = useQuery({
    queryKey: ["signed", allPaths],
    enabled: allPaths.length > 0,
    staleTime: 30 * 60 * 1000,
    queryFn: async () => {
      const { data } = await supabase.storage.from("clips").createSignedUrls(allPaths, 3600);
      return Object.fromEntries((data ?? []).map((d) => [d.path, d.signedUrl])) as Record<string, string>;
    },
  });
  const urlOf = (p: string) => urls.data?.[p];

  const sel = items.find((i) => i.id === selected) ?? null;
  const current = playing ? items[cursor] : sel ?? items[0];

  // load the current item into the player
  useEffect(() => {
    const v = videoRef.current;
    if (!v || !current) return;
    const url = urlOf(current.path);
    if (!url) return;
    if (v.dataset["src"] !== url) {
      v.dataset["src"] = url;
      v.src = url;
    }
    const seek = () => {
      v.currentTime = current.in;
      if (playing) v.play().catch(() => {});
    };
    if (v.readyState >= 1) seek();
    else v.onloadedmetadata = seek;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [current?.id, current?.in, playing, urls.data]);

  function onTime() {
    const v = videoRef.current;
    if (!v || !current) return;
    if (v.currentTime >= current.out - 0.05) {
      if (playing && cursor < items.length - 1) setCursor(cursor + 1);
      else {
        v.pause();
        if (playing) setPlaying(false);
      }
    }
  }

  function togglePlay() {
    if (playing) {
      videoRef.current?.pause();
      setPlaying(false);
    } else if (items.length) {
      setCursor(0);
      setPlaying(true);
    }
  }

  async function add(m: Media) {
    const url = urlOf(m.path);
    if (!url) return;
    try {
      const d = await probeDuration(url);
      const it = { id: crypto.randomUUID(), path: m.path, name: m.name, in: 0, out: d, duration: d };
      setItems((x) => [...x, it]);
      setSelected(it.id);
    } catch (e) {
      toast.error((e as Error).message);
    }
  }

  async function upload(file: File) {
    setUploading(true);
    try {
      await uploadFootage(file);
      qc.invalidateQueries({ queryKey: ['media'] });
      qc.invalidateQueries({ queryKey: ['library'] });
      toast.success("Footage uploaded");
    } catch (e) { toast.error((e as Error).message); }
    finally { setUploading(false); }
  }

  async function renderEdit() {
    setExporting(true); setResult(null); setExportStatus('Preparing export…');
    const abort = new AbortController(); controller.current = abort;
    try {
      const { exportTimeline } = await import('@/lib/local-export');
      const blob = await exportTimeline(items, urls.data ?? {}, format, abort.signal, setExportStatus);
      const preview = URL.createObjectURL(blob);
      try { const duration = await probeDuration(preview); if (!Number.isFinite(duration) || duration <= 0) throw new Error('The exported file could not be verified.'); }
      finally { URL.revokeObjectURL(preview); }
      if (!abort.signal.aborted) { setResult(blob); setExportStatus('MP4 ready'); }
    } catch (e) { setExportStatus(abort.signal.aborted ? 'Export cancelled' : (e as Error).message); toast.error(abort.signal.aborted ? 'Export cancelled' : (e as Error).message); }
    finally { setExporting(false); controller.current = null; }
  }

  function update(id: string, patch: Partial<Item>) {
    setItems((x) => x.map((i) => (i.id === id ? { ...i, ...patch } : i)));
  }
  function move(idx: number, dir: -1 | 1) {
    setItems((x) => {
      const n = [...x];
      const j = idx + dir;
      if (j < 0 || j >= n.length) return x;
      const current = n[idx]; const other = n[j];
      if (!current || !other) return x;
      [n[idx], n[j]] = [other, current];
      return n;
    });
  }
  function cut() {
    const v = videoRef.current;
    if (!sel || !v) { toast.message("Select a scene first."); return; }
    const t = v.currentTime;
    if (t <= sel.in + 0.2 || t >= sel.out - 0.2) { toast.message("Move the playhead inside the scene to cut."); return; }
    const b = { ...sel, id: crypto.randomUUID(), in: t };
    setItems((x) => x.flatMap((i) => (i.id === sel.id ? [{ ...i, out: t }, b] : [i])));
  }
  async function save() {
    setSaving(true);
    const { error } = await supabase.from("video_projects").update({ timeline: items }).eq("id", projectId);
    setSaving(false);
    if (error) toast.error(error.message);
    else {
      toast.success("Edit saved");
      qc.invalidateQueries({ queryKey: ["projects"] });
    }
  }

  const total = items.reduce((s, i) => s + (i.out - i.in), 0);

  return (
    <section className="mb-8 rounded-2xl border border-border bg-background/40 p-3 sm:p-5">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h3 className="text-base font-bold">Editor</h3>
          <p className="text-sm text-muted-foreground">Arrange scenes, trim, cut, and mix in your own footage.</p>
        </div>
        <Button onClick={save} disabled={saving} variant="outline" className="h-11 w-full sm:h-9 sm:w-auto">
          {saving ? <Loader2 className="animate-spin" /> : <Save />} Save edit
        </Button>
      </div>
      <div className="mt-4 grid grid-cols-2 items-center gap-2 sm:flex sm:flex-wrap">
        <Select value={format} onValueChange={(v) => setFormat(v as OutputFormat)} disabled={exporting}>
          <SelectTrigger aria-label="Export format" className="h-11 w-full sm:h-9 sm:w-40"><SelectValue /></SelectTrigger>
          <SelectContent>{FORMATS.map((f) => <SelectItem key={f} value={f}>{f} · {f === '9:16' ? 'Vertical' : f === '16:9' ? 'Landscape' : 'Square'}</SelectItem>)}</SelectContent>
        </Select>
        <Button onClick={renderEdit} disabled={!items.length || exporting || playing} variant="outline" className="h-11 sm:h-9"><Download /> Export MP4</Button>
        {exporting && <Button variant="ghost" className="h-11 sm:h-9" title="Cancel export" aria-label="Cancel export" onClick={() => controller.current?.abort()}><X /> Cancel</Button>}
        {result && <Button className="h-11 sm:h-9" onClick={() => downloadVideo(result)}><Download /> Download MP4</Button>}
        <span role="status" className="col-span-2 text-xs text-muted-foreground">{exporting && <Loader2 className="mr-1 inline h-3 w-3 animate-spin" />}{exportStatus}</span>
      </div>
      <p className="mt-2 text-xs text-muted-foreground">Local export · up to 5 minutes / 150 MB · 360p landscape/vertical or 480p square. Larger edits may exceed your device memory. No AI credits used.</p>

      <div className="mt-4 grid gap-4 lg:grid-cols-[1fr_220px]">
        <div>
          <div className={`mx-auto overflow-hidden rounded-xl bg-muted ${vertical ? "max-w-[240px] sm:max-w-[280px]" : ""}`}>
            {items.length ? (
              <video
                ref={videoRef}
                onTimeUpdate={onTime}
                controls={!playing}
                playsInline
                className={`w-full ${vertical ? "aspect-[9/16]" : "aspect-video"} object-contain`}
              />
            ) : (
              <div className={`grid place-items-center text-sm text-muted-foreground ${vertical ? "aspect-[9/16]" : "aspect-video"}`}>
                Add a scene from your media to start
              </div>
            )}
          </div>
          <div className="mt-3 grid grid-cols-2 items-center gap-2 sm:flex sm:flex-wrap">
            <Button size="sm" className="h-11 text-sm sm:h-8 sm:text-xs" onClick={togglePlay} disabled={!items.length}>
              {playing ? <Pause /> : <Play />} {playing ? "Pause" : "Play edit"}
            </Button>
            <Button size="sm" variant="outline" className="h-11 text-sm sm:h-8 sm:text-xs" onClick={cut} disabled={!sel || playing}>
              <Scissors /> Cut at playhead
            </Button>
            <span className="col-span-2 text-center text-xs text-muted-foreground sm:ml-auto">Total {fmt(total)}</span>
          </div>
        </div>

        <div className="rounded-xl border border-border p-3">
          <div className="mb-2 flex items-center justify-between">
            <p className="text-xs font-semibold uppercase text-muted-foreground">Media</p>
            <label className="inline-flex min-h-10 cursor-pointer items-center rounded-md px-2 text-sm text-primary hover:underline sm:min-h-0 sm:text-xs">
              {uploading ? "Uploading…" : (
                <span className="inline-flex items-center gap-1"><Upload className="h-3 w-3" /> Upload</span>
              )}
              <input
                type="file"
                accept="video/*"
                className="hidden"
                disabled={uploading}
                onChange={(e) => {
                  const f = e.target.files?.[0];
                  if (f) upload(f);
                  e.target.value = "";
                }}
              />
            </label>
          </div>
          <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search name or tag" aria-label="Search media" className="mb-2 h-10 w-full rounded-md border border-border bg-transparent px-3 text-base outline-none sm:h-8 sm:px-2 sm:text-xs" />
          <div className="max-h-64 space-y-1 overflow-y-auto">
            {(media.data ?? []).length === 0 && (
              <p className="py-2 text-xs text-muted-foreground">Generate an AI clip or upload footage.</p>
            )}
            {(media.data ?? []).filter((m) => { const t = q.trim().toLowerCase(); return !t || m.name.toLowerCase().includes(t) || (m.tags ?? []).some((x) => x.includes(t)); }).map((m) => (
              <button
                key={m.path}
                onClick={() => add(m)}
                className="flex min-h-11 w-full items-center gap-2 rounded-md px-2 py-2 text-left text-sm hover:bg-accent active:bg-accent sm:min-h-0 sm:py-1.5"
              >
                <Plus className="h-3 w-3 shrink-0 text-primary" />
                <span className="truncate">{m.name}</span>
                <span className="ml-auto text-[10px] uppercase text-muted-foreground">{m.kind === "ai" ? "AI" : "Yours"}</span>
              </button>
            ))}
          </div>
        </div>
      </div>

      <div className="mt-5 space-y-2">
        <p className="text-xs font-semibold uppercase text-muted-foreground">Timeline</p>
        <div className="flex h-4 overflow-hidden rounded-full bg-muted sm:h-3">
          {items.map((i, idx) => (
            <div
              key={i.id}
              style={{ flexGrow: i.out - i.in }}
              className={`border-r border-background ${idx % 2 ? "bg-secondary" : "bg-primary"} ${playing && idx === cursor ? "opacity-100" : "opacity-70"}`}
            />
          ))}
        </div>
        {items.map((i, idx) => (
          <div
            key={i.id}
            onClick={() => !playing && setSelected(i.id)}
            className={`rounded-lg border p-3 ${selected === i.id ? "border-primary bg-accent" : "border-border"}`}
          >
            <div className="grid grid-cols-[auto_minmax(0,1fr)_auto] items-center gap-2 text-sm">
              <span className="font-display text-xs text-primary">{idx + 1}</span>
              <div className="min-w-0 sm:flex sm:items-center sm:gap-2">
                <p className="truncate">{i.name}</p>
                <p className="text-xs text-muted-foreground sm:ml-auto sm:shrink-0">{fmt(i.in)} – {fmt(i.out)}</p>
              </div>
              <div className="flex shrink-0 items-center">
                <button className={tapBtn} aria-label="Move up" disabled={idx === 0} onClick={(e) => { e.stopPropagation(); move(idx, -1); }}><ArrowUp className="h-4 w-4" /></button>
                <button className={tapBtn} aria-label="Move down" disabled={idx === items.length - 1} onClick={(e) => { e.stopPropagation(); move(idx, 1); }}><ArrowDown className="h-4 w-4" /></button>
                <button className={tapBtn} aria-label="Remove scene" onClick={(e) => { e.stopPropagation(); setItems((x) => x.filter((y) => y.id !== i.id)); }}>
                  <Trash2 className="h-4 w-4 text-muted-foreground" />
                </button>
              </div>
            </div>
            {selected === i.id && (
              <Slider
                className="mt-4 py-2 sm:mt-3 sm:py-0"
                aria-label="Trim scene"
                min={0}
                max={i.duration}
                step={0.1}
                minStepsBetweenThumbs={1}
                value={[i.in, i.out]}
                onValueChange={([a, b]) => {
                  if (a === undefined || b === undefined) return;
                  update(i.id, { in: a, out: b });
                  if (videoRef.current) videoRef.current.currentTime = a !== i.in ? a : b;
                }}
              />
            )}
          </div>
        ))}
      </div>
    </section>
  );
}
