import { Link, useNavigate } from '@tanstack/react-router';
import { queryOptions, useSuspenseQuery } from '@tanstack/react-query';
import { Film, FolderOpen, Plus } from 'lucide-react';
import { SiteHeader } from '@/components/SiteHeader';
import { Button } from '@/components/ui/button';
import { listProjects } from '@/lib/studio.functions';
export const projectsOptions = queryOptions({ queryKey: ['projects'], queryFn: () => listProjects() });
export function ProjectsView({ dashboard = false }: { dashboard?: boolean }) {
  const { data } = useSuspenseQuery(projectsOptions); const navigate = useNavigate();
  const rows = dashboard ? data.slice(0, 6) : data;
  return <><SiteHeader /><main className="mx-auto max-w-6xl px-5 py-10"><div className="flex flex-wrap items-center justify-between gap-4"><div><p className="mb-2 text-xs font-semibold uppercase text-primary">Net Studio AI</p><h1 className="text-3xl font-bold">{dashboard ? 'Your creative workspace' : 'My projects'}</h1></div><Button asChild><Link to="/studio"><Plus /> Create video</Link></Button></div>
    {dashboard && <section className="my-8 grid gap-5 border-y border-border py-6 sm:grid-cols-3"><div><p className="text-3xl font-bold">{data.length}</p><p className="text-sm text-muted-foreground">Saved projects</p></div><div><p className="text-xl font-bold text-primary">Free local editing</p><p className="text-sm text-muted-foreground">Uploads, trims & supported MP4 exports</p></div><div><p className="text-xl font-bold">AI is optional</p><Button asChild variant="link" className="h-auto px-0"><Link to="/settings">Manage usage</Link></Button></div></section>}
    <h2 className="mb-5 mt-8 text-xl font-semibold">{dashboard ? 'Recent projects' : 'Saved work'}</h2>{!rows.length ? <div className="border-y border-border py-12 text-center"><FolderOpen className="mx-auto mb-4 h-10 w-10 text-primary" /><p className="text-muted-foreground">No projects yet.</p></div> : <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">{rows.map((p) => <Button key={p.id} variant="outline" className="h-auto min-w-0 items-start justify-start whitespace-normal p-5 text-left" onClick={() => navigate({ to: '/studio', search: { project: p.id } })}><Film className="mt-1 shrink-0 text-primary" /><span className="min-w-0"><span className="block break-words font-semibold">{p.topic}</span><span className="mt-2 block text-xs text-muted-foreground">{p.platform} · {p.duration}</span><span className="mt-2 block text-xs text-muted-foreground">{new Date(p.created_at).toLocaleDateString()}</span></span></Button>)}</div>}
  </main></>;
}