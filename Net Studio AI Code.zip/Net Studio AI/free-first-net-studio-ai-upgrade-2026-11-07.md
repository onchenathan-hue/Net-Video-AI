# Free-first Net Studio AI upgrade

## Inspection results

Keep the existing dark, electric-lime/coral design, sign-in, saved projects and media library.

The studio already supports written video plans, 8-second AI clips, short animated story reels, uploaded footage, tags/search, playback, scene reordering, trimming, cutting and saved timelines. It does **not** export the timeline as a combined MP4. Long-form options currently generate written plans, not complete long videos.

The current AI calls spend Lovable workspace credits. The homepage advertises $19/$49 subscriptions and limits that are not enforced. Those offers conflict with your new free-first brief. Scene rendering currently depends on keeping the studio open; queue coordination and failure handling need strengthening.

## What “free-first” can honestly provide

- Uploading, editing, manual script/storyboard creation and supported local exports without a mandatory paid AI service. Hosting/storage still have their own usage limits; do not claim unlimited free operation.
- Optional open-source video engines, subject to hardware or a verified provider quota. Open-source models do not imply free hosted GPU processing.
- Hugging Face publicly documents **$0.10 monthly inference credits for free accounts, subject to change**. This does not establish this account's remaining quota, video-model coverage or even one free video. Show account quota as **unverified** until checked; never invent a clip allowance.
- Existing credit-funded AI stays available only as an explicitly enabled optional service. No automatic charging, subscription gating or automatic paid fallback.
- No fake previews, placeholder videos, fabricated progress or “generated” label before a real media file is saved and playable.

## Stage 1 — usable free core and real MP4 export

1. Replace subscription offers with truthful local-processing and optional-provider availability information, preserving the existing visual identity.
2. Add a dashboard, My Projects and Settings, with a manual Create Video path that works without an AI call. Keep the library and existing editor accessible.
3. Make optional credit-funded services disabled by default, including server-side checks so opening an old project cannot silently start queued paid scenes.
4. Add browser-side MP4 rendering for trimmed and reordered uploaded/finished clips. Show actual rendering activity, cancellation, errors and an MP4 download only after successful output verification.
5. Offer 9:16, 16:9 and 1:1 output formats with documented browser/device limits. Start with small projects; do not promise 60-minute browser rendering on every device.
6. Harden uploads, save failures and missing-session handling. Test editing and export using actual media.

**Stage 1 acceptance:** signed-in user creates a project without spending AI credits, uploads two real clips, trims/reorders them, saves/reopens the edit and downloads a playable combined MP4. Optional paid generation remains off unless explicitly enabled.

## Stage 2 — scripts and editable storyboards

- Add dedicated Create Video, YouTube Shorts, Long Video and AI Script Writer views, reusing the same project workflow rather than separate data silos.
- Editable script and scenes with visual descriptions, narration text, captions, duration, scene count, format and engine-dependent resolution choices.
- Original realistic, cinematic, 2D, 3D, cartoon, history documentary, anime-inspired, sports and educational styles. Replace the existing brand-specific animation style label with an original descriptive label.
- New long-production presets through 60 minutes, while preserving existing longer written-planning features.
- Manual writing always works; AI script/prompt enhancement requires an available optional engine and displays its actual limits.

**Stage 2 acceptance:** changes to individual scenes persist across reloads and are reflected in the editor; manual creation never invokes a paid provider.

## Stage 3 — verified optional generation engines

- Introduce a modular provider interface for capability checks, text-to-video, image-to-video, job status, media retrieval and safe errors.
- Investigate exact Wan/LTX routes through Hugging Face and compatible user-supplied local/self-hosted services. Connect only documented, reachable endpoints; don't expose an arbitrary server-side URL proxy.
- Keep credentials server-side. Display capability, quota verification status, supported durations/formats/resolutions and availability. Unknown pricing or balance is not permission to send a potentially paid job.
- If a provider cannot enforce free-only usage, leave its generation disabled in free mode. No automatic upgrade or fallback to paid generation.
- Persist jobs before dispatch; atomically claim queued scenes, prevent duplicate jobs, save returned files privately and preserve terminal denial/refusal/credit errors across reloads. Retry only eligible transient failures with bounded backoff.
- Individual-scene regeneration requires a new user action and displays the applicable usage limits.

**Stage 3 acceptance:** verify a real returned video end-to-end only after a compatible endpoint and account access are available. If none is available, show “No verified free video-generation capacity” and keep local editing working. This is a named dependency, not a simulated result.

## Stage 4 — audio, subtitles and long-video production

- Accept narration, music and sound-effect files, with independent volume controls and rights-safe usage.
- Browser voices may provide optional narration preview, but are not presented as downloadable speech: standard browser speech synthesis does not provide a reusable audio file.
- Support downloadable narration through a verified local tool such as Piper or a genuinely available optional provider; show only voices actually returned by that engine, including male/female choices where supported.
- Editable timed subtitles; burn into export and offer subtitle-file download. Automatic transcription/alignment is enabled only with a verified local or optional service, not inferred from script text.
- Build a persisted pipeline: script → scenes → available clips → narration/subtitles → assembly → verified MP4. Allow stopping, resuming and editing scenes. Measure progress from completed work, not timers.
- Support long timelines through 60 minutes. For projects too large for browser export, offer a local-render package/workflow instead of requiring a paid rendering service. Local GPU/video software installation may be needed for full automatic production.

**Stage 4 acceptance:** actual narration/subtitles/audio mix appear in the exported file; verify a short full production first, then separately test larger projects and report device limits.

## Testing at every stage

- Keep small concrete tests for free-only defaults, no paid fallback, supported settings, upload limits, timeline trims and generation state transitions.
- Verify signed-in save/reload, real uploads, local exports, error states and private-project access. Check desktop/mobile layout and runtime/build errors.
- Test each newly connected AI endpoint against its documented protocol; stop on unavailable endpoints, access denial or account problems rather than substituting providers silently.
- No claim that all features work until their real output has been inspected. Record external blockers and what remains unverified.

## Technical approach

- Preserve TanStack Start routing and Lovable Cloud authentication/private storage. New public tables require RLS, ownership policies and explicit grants.
- Browser-only, dynamically loaded FFmpeg WebAssembly handles modest local exports; never run native FFmpeg or GPU inference in the hosted server runtime.
- Shared project/scene types connect creation, storyboard and editor views. Provider credentials and secret-backed calls stay inside authenticated server functions.
- Atomic queue claims and persistent paused states guard every automated entry point. Finished video files are saved immediately; signed URLs remain private.
- Record architecture rules in AGENTS.md and track stages in roadmap.md.

## Sources and known limits

- [Hugging Face pricing](https://huggingface.co/docs/inference-providers/main/en/pricing): public credits, not account balance.
- [Hugging Face provider capabilities](https://huggingface.co/docs/inference-providers/main/index): provider-level video support does not guarantee a specific model or free access.
- [Wan model information](https://huggingface.co/Wan-AI/Wan2.1-T2V-14B) and [LTX-Video](https://huggingface.co/Lightricks/LTX-Video): local hardware requirements vary by model; ordinary phones cannot be assumed to run them.
- [FFmpeg WebAssembly limits](https://ffmpegwasm.netlify.app/docs/faq/): slower than native FFmpeg, significant memory use; its published file ceiling is not a promise that large exports work on every device.
- [Web Speech API](https://developer.mozilla.org/en-US/docs/Web/API/Web_Speech_API) and [Piper](https://github.com/OHF-Voice/piper1-gpl): device-dependent preview versus separately generated audio; review individual voice/model licenses.

This approval starts Stage 1. Later stages follow tested working foundations, with provider-dependent work explicitly blocked until real access is verified.