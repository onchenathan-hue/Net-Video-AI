import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { BookOpen, Film, Loader2, Send } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { STYLES, advanceReel, checkClip, createClip, createStoryReel, listClips, reelToTimeline } from "@/lib/clips.functions";
import { getSettings } from '@/lib/settings.functions';

export function ClipPanel({ projectId, vertical }: { projectId: string; vertical: boolean }) {
  const qc = useQueryClient();
  const key = ["clips", projectId];
  const clips = useQuery({ queryKey: key, queryFn: () => listClips({ data: { projectId } }) });
  const settings = useQuery({ queryKey: ['settings'], queryFn: () => getSettings() });
  const enabled = settings.data?.paid_ai_enabled === true;
  const create = useMutation({
    mutationFn: () => createClip({ data: { projectId } }),
    onSuccess: () => qc.invalidateQueries({ queryKey: key }),
    onError: (e: Error) => toast.error(e.message),
  });

  const [style, setStyle] = useState<(typeof STYLES)[number]>(STYLES[0]);
  const [count, setCount] = useState("4");
  const reel = useMutation({
    mutationFn: () => createStoryReel({ data: { projectId, style, scenes: Number(count) } }),
    onSuccess: () => { toast.success("Story planned — rendering scenes one by one"); qc.invalidateQueries({ queryKey: key }); },
    onError: (e: Error) => toast.error(e.message),
  });
  const toEditor = useMutation({
    mutationFn: (reelId: string) => reelToTimeline({ data: { projectId, reelId } }),
    onSuccess: (r) => { toast.success(`${r.count} scenes added to the editor`); qc.invalidateQueries({ queryKey: ["projects"] }); qc.invalidateQueries({ queryKey: ["media", projectId] }); },
    onError: (e: Error) => toast.error(e.message),
  });

  const pending = (clips.data ?? []).filter((c) => c.status === "in_progress");
  const queued = (clips.data ?? []).filter((c) => c.status === "queued");
  const reels = Object.values(
    (clips.data ?? []).filter((c) => c.reel_id).reduce<Record<string, NonNullable<typeof clips.data>>>((a, c) => {
      (a[c.reel_id!] ??= []).push(c); return a;
    }, {}),
  ).map((sc) => sc.sort((a, b) => (a.scene_index ?? 0) - (b.scene_index ?? 0)));

  useEffect(() => {
    if (!enabled || pending.length || !queued.length) return;
    advanceReel({ data: { projectId } })
      .then(() => qc.invalidateQueries({ queryKey: key }))
      .catch((e: Error) => toast.error(e.message));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [pending.length, queued.length, enabled]);
  useEffect(() => {
    if (pending.length === 0) return;
    const t = setInterval(async () => {
      try {
        const results = await Promise.all(pending.map((c) => checkClip({ data: { clipId: c.id } })));
        if (results.some((r) => r.status !== "in_progress")) {
          results.filter((r) => r.status === "failed").forEach((r) => toast.error(r.error ?? "Clip failed"));
          qc.invalidateQueries({ queryKey: key });
        }
      } catch (e) {
        toast.error((e as Error).message);
        clearInterval(t);
      }
    }, 8000);
    return () => clearInterval(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [pending.map((c) => c.id).join(",")]);

  const busy = create.isPending || reel.isPending || pending.length > 0 || queued.length > 0;

  return (
    <section className="mb-8 rounded-2xl border border-border bg-background/40 p-3 sm:p-5">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h3 className="text-base font-bold">Video clips</h3>
          <p className="text-sm text-muted-foreground">Turn this script into an 8-second clip with sound.</p>
        </div>
        <Button onClick={() => create.mutate()} disabled={busy || !enabled} className="h-11 w-full shadow-glow sm:h-9 sm:w-auto">
          {busy ? <Loader2 className="animate-spin" /> : <Film />}
          {create.isPending ? "Starting…" : pending.length ? "Rendering…" : "Generate video clip"}
        </Button>
      </div>
      {!enabled && <p className="mt-3 text-sm text-muted-foreground">No verified free video-generation capacity. Optional credit-funded AI is off in Settings; uploaded footage and finished clips remain usable.</p>}
      <div className="mt-5 rounded-xl border border-primary/40 bg-accent/30 p-3 sm:p-4">
        <div className="flex items-center gap-2 font-semibold"><BookOpen className="h-4 w-4 text-primary" /> Story reel</div>
        <p className="mt-1 text-sm text-muted-foreground">Turn the script into an animated story: same character in every scene, narration, captions and music.</p>
        <div className="mt-3 grid gap-2 sm:flex sm:flex-wrap sm:items-center">
          <Select value={style} onValueChange={(v) => setStyle(v as (typeof STYLES)[number])}>
            <SelectTrigger aria-label="Visual style" className="h-11 w-full sm:h-9 sm:w-56"><SelectValue /></SelectTrigger>
            <SelectContent>{STYLES.map((s) => <SelectItem key={s} value={s}>{s}</SelectItem>)}</SelectContent>
          </Select>
          <Select value={count} onValueChange={setCount}>
            <SelectTrigger aria-label="Number of scenes" className="h-11 w-full sm:h-9 sm:w-36"><SelectValue /></SelectTrigger>
            <SelectContent>{["2", "3", "4", "5", "6"].map((n) => <SelectItem key={n} value={n}>{n} scenes · {Number(n) * 8}s</SelectItem>)}</SelectContent>
          </Select>
          <Button className="h-11 sm:h-9" onClick={() => reel.mutate()} disabled={busy || !enabled}>
            {reel.isPending ? <><Loader2 className="animate-spin" /> Writing story…</> : "Create story reel"}
          </Button>
        </div>
        {reels.map((sc) => {
          const done = sc.filter((c) => c.status === "completed").length;
          return (
            <div key={sc[0]!.reel_id} className="mt-4 rounded-lg border border-border p-3">
              <div className="flex flex-wrap items-center gap-2 text-sm">
                <span>Reel · {done}/{sc.length} scenes ready</span>
                <Button size="sm" variant="outline" className="h-10 w-full sm:ml-auto sm:h-8 sm:w-auto" disabled={!done || toEditor.isPending} onClick={() => toEditor.mutate(sc[0]!.reel_id!)}>
                  <Send /> Send to editor
                </Button>
              </div>
              <ol className="mt-2 space-y-1 text-xs text-muted-foreground">
                {sc.map((c) => (
                  <li key={c.id}>{(c.scene_index ?? 0) + 1}. {c.caption} — {c.status === "completed" ? "ready" : c.status === "failed" ? "failed" : c.status === "queued" ? "waiting" : "rendering…"}</li>
                ))}
              </ol>
            </div>
          );
        })}
      </div>
      {(pending.length > 0 || queued.length > 0) && (
        <p className="mt-3 text-sm text-muted-foreground">Rendering usually takes 1–3 minutes. You can keep browsing.</p>
      )}
      <div className={`mt-4 grid gap-3 sm:gap-4 ${vertical ? "grid-cols-2 sm:grid-cols-3" : "sm:grid-cols-2"}`}>
        {(clips.data ?? [])
          .filter((c) => c.status === "completed" && c.url)
          .map((c) => (
            <div key={c.id} className="overflow-hidden rounded-xl border border-border">
              <video src={c.url!} controls playsInline className={`w-full bg-muted ${vertical ? "aspect-[9/16]" : "aspect-video"}`} />
              <a href={c.url!} download className="block px-3 py-3 text-sm text-primary hover:underline sm:py-2 sm:text-xs">
                Download MP4
              </a>
            </div>
          ))}
      </div>
    </section>
  );
}
