import { useEffect, useState } from "react";
import { Download, MoreVertical, PlusSquare, Share } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { detectInstallPlatform, type InstallPlatform } from "@/lib/pwa-guards";

type InstallPromptEvent = Event & { prompt: () => Promise<void>; userChoice: Promise<{ outcome: "accepted" | "dismissed" }> };

export function InstallAppButton({ className, size = "sm" }: { className?: string; size?: "sm" | "default" | "lg" }) {
  const [prompt, setPrompt] = useState<InstallPromptEvent | null>(null);
  const [installed, setInstalled] = useState(true); // hidden until checked on the device
  const [platform, setPlatform] = useState<InstallPlatform>("desktop");
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const nav = navigator as Navigator & { standalone?: boolean };
    setInstalled(window.matchMedia("(display-mode: standalone)").matches || nav.standalone === true);
    setPlatform(detectInstallPlatform(navigator.userAgent, navigator.platform, navigator.maxTouchPoints));
    const onPrompt = (e: Event) => { e.preventDefault(); setPrompt(e as InstallPromptEvent); };
    const onInstalled = () => { setInstalled(true); setPrompt(null); setOpen(false); };
    window.addEventListener("beforeinstallprompt", onPrompt);
    window.addEventListener("appinstalled", onInstalled);
    return () => { window.removeEventListener("beforeinstallprompt", onPrompt); window.removeEventListener("appinstalled", onInstalled); };
  }, []);

  if (installed) return null;

  async function install() {
    if (!prompt) { setOpen(true); return; }
    await prompt.prompt();
    const { outcome } = await prompt.userChoice;
    setPrompt(null);
    if (outcome === "accepted") setInstalled(true);
  }

  return (
    <>
      <Button size={size} variant="outline" className={className} onClick={install}>
        <Download /> Install app
      </Button>
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-sm">
          <DialogHeader>
            <DialogTitle>Install Net Studio AI</DialogTitle>
            <DialogDescription>Add the app to your home screen for full-screen editing and faster start-up on mobile data.</DialogDescription>
          </DialogHeader>
          {platform === "ios" ? (
            <ol className="space-y-3 text-sm">
              <Step n={1}>Open this page in <strong>Safari</strong>.</Step>
              <Step n={2}>Tap the <Share className="inline h-4 w-4 text-primary" aria-label="Share" /> <strong>Share</strong> button in the toolbar.</Step>
              <Step n={3}>Scroll down and tap <PlusSquare className="inline h-4 w-4 text-primary" aria-label="Add" /> <strong>Add to Home Screen</strong>, then <strong>Add</strong>.</Step>
            </ol>
          ) : platform === "android" ? (
            <ol className="space-y-3 text-sm">
              <Step n={1}>Open this page in <strong>Chrome</strong>.</Step>
              <Step n={2}>Tap the <MoreVertical className="inline h-4 w-4 text-primary" aria-label="Menu" /> menu in the top corner.</Step>
              <Step n={3}>Tap <strong>Install app</strong> or <strong>Add to Home screen</strong>.</Step>
            </ol>
          ) : (
            <ol className="space-y-3 text-sm">
              <Step n={1}>In Chrome or Edge, click the install icon at the right of the address bar.</Step>
              <Step n={2}>On a phone, open this page and use your browser's <strong>Add to Home Screen</strong> option.</Step>
            </ol>
          )}
          <p className="text-xs text-muted-foreground">Installing is free. You still need an internet or mobile-data connection to sign in, sync projects and upload footage.</p>
        </DialogContent>
      </Dialog>
    </>
  );
}

function Step({ n, children }: { n: number; children: React.ReactNode }) {
  return (
    <li className="flex gap-3">
      <span className="grid h-6 w-6 shrink-0 place-items-center rounded-full bg-primary text-xs font-bold text-primary-foreground">{n}</span>
      <span className="min-w-0 pt-0.5">{children}</span>
    </li>
  );
}
