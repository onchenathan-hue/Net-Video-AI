# Free-first video platform upgrade

- [x] Inspect existing studio and research free processing/provider limits.
- [x] Stage 1: remove subscription claims; add free editing workspace, honest usage settings and local MP4 export.
- [x] Stage 1 tests: free AI defaults, format/upload/export limits, real authenticated uploads, saved trims/reordering and playable combined MP4.

## Later stages (outside approved Stage 1 execution)
- Stage 2: editable scripts/storyboards, scene settings and original visual styles.
- Stage 3: optional verified providers, image-to-video and reliable generation jobs.
- Stage 4: narration files, subtitles, audio mixing and long-video assembly.
- Stage 5: expanded privacy and compatibility tests for later features.

Provider-dependent generation is blocked until a compatible endpoint and account quota can be verified; it must never be represented as guaranteed free.
## Mobile app (requested Nov 10)
- [x] Installable app: manifest, icons, iOS/Android head tags.
- [x] Install App button (Android prompt + iOS Add to Home Screen guidance).
- [x] Guarded offline/app-shell service worker (published app only).
- [x] Touch-friendly phone layout for studio, editor timeline, clip panel and player.
