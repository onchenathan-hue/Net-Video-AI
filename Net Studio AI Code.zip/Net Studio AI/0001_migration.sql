CREATE TABLE public.video_clips (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  project_id uuid NOT NULL REFERENCES public.video_projects(id) ON DELETE CASCADE,
  job_id text,
  status text NOT NULL DEFAULT 'queued',
  prompt text NOT NULL,
  storage_path text,
  error text,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.video_clips TO authenticated;
GRANT ALL ON public.video_clips TO service_role;
ALTER TABLE public.video_clips ENABLE ROW LEVEL SECURITY;
CREATE POLICY "own clips select" ON public.video_clips FOR SELECT TO authenticated USING (auth.uid() = user_id);
CREATE POLICY "own clips insert" ON public.video_clips FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
CREATE POLICY "own clips update" ON public.video_clips FOR UPDATE TO authenticated USING (auth.uid() = user_id);
CREATE POLICY "own clips delete" ON public.video_clips FOR DELETE TO authenticated USING (auth.uid() = user_id);

CREATE POLICY "own clip files read" ON storage.objects FOR SELECT TO authenticated
  USING (bucket_id = 'clips' AND (storage.foldername(name))[1] = auth.uid()::text);
CREATE POLICY "own clip files insert" ON storage.objects FOR INSERT TO authenticated
  WITH CHECK (bucket_id = 'clips' AND (storage.foldername(name))[1] = auth.uid()::text);