<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.

## What Lovable manages

Rules outside this block are the project's own. Change the pieces below in
Lovable, not by hand. With the [Lovable MCP](https://mcp.lovable.dev)
connected, `send_message` asks Lovable to do it; otherwise ask the user to
use the editor.

- **Database.** Do not add or edit `supabase/migrations/` or `drizzle/`.
  Ask Lovable to change the schema.
- **Generated files.** Do not edit a file whose header says it is automatically
  generated.
- **AI gateway.** Keep model calls on Lovable's gateway, and keep
  `LOVABLE_API_KEY` out of browser code.
- **Connectors.** Lovable provides native connectors. `list_connectors` shows
  which are enabled; `add_connector` only returns the dashboard link. When a
  connector is enabled, calls go through the connector gateway and need
  `LOVABLE_API_KEY`. When Lovable does not provide one, users can bring their
  own key and store it in Secrets.
- **Secrets.** Lovable manages them. Do not put secret values in the repo.
<!-- LOVABLE:END -->

- Keep paid-AI consent in private studio_settings and enforce it in every generation/queue entry point; browser toggles alone cannot prevent credit spending.
- Use manual and AI creation paths over the same video_projects records so saved work remains interoperable.
- Load FFmpeg WebAssembly only from browser event handlers and package its matching core/worker assets; hosted server functions cannot transcode video.
- Keep free-mode and media-validation rules in shared pure utilities with concrete tests so UI and generation gates remain consistent.
- Register the offline service worker only from src/lib/pwa.ts using the pure guards in src/lib/pwa-guards.ts; it must never run in dev, iframes or Lovable preview hosts, because stale workers break previews.
- Scope vite-plugin-pwa to the client build environment and its outDir (see vite.config.ts); TanStack Start builds several environments and the worker must land in the public client output.
